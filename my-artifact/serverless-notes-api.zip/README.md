# sls-rest-api

Updating the readme
